# ITP_PROJECT
Student Result and Examination Management System
