const data=[
    {
        question:"what does CSS stand for?",
        incorrectAnswer:[
            "Computer Style Sheets",
            "Creative Style Sheets",
            "Colorful Style Sheets",
        ],
        correctAnswer:"Cascading Style Sheets",
    },
    {
        question:"What is an operating system?",
       
        incorrectAnswer:[
            "interface between the hardware and application programs",
            "collection of programs that manages hardware resources",
            " system service provider to the application program",
            
        ],
        correctAnswer:"all of the mentioned",
    },
];
export default data;