// import React from 'react'

export const NoMatch = () =>{
  return <div> Page not found </div>
  
};
