import React from 'react'

 function studentResult() {
  return (
    <div>
      <h1>Hello</h1>
      <h3>hhhhh</h3>
      </div>
  );

 }
export default studentResult;
